# Thymeleaf Basic

![](demo.jpg)