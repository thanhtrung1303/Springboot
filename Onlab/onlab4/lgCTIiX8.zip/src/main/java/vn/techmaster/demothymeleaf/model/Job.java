package vn.techmaster.demothymeleaf.model;

public record Job(String language, String code, String display) {
  
}
