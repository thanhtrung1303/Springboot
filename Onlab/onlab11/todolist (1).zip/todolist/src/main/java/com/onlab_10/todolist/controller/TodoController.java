package com.onlab_10.todolist.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.onlab_10.todolist.model.Todo;
import com.onlab_10.todolist.request.UpdateTodoRequest;

@RestController
@RequestMapping("api/v1")
public class TodoController {
    
    // lay danh sach tat ca coong viec 
    @GetMapping("/todos")
    public List<Todo> getTodos(@RequestParam(required = false) String status) {

        return null;
    }

        // lay cong viec theo id
    @GetMapping("/todos/{id}")

    
    // tao moi cong viec 
    @PostMapping("/todos")



    // cap nhat conog viec
     @PutMapping("/todos/{id}")
    public Todo updateTodo(@PathVariable int id, @RequestBody UpdateTodoRequest request) {
        return null;
    }


    // Xoa cong viec 
}
