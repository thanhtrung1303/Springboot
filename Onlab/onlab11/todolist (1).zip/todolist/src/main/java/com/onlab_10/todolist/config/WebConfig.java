package com.onlab_10.todolist.config;

public class WebConfig {
    
}
