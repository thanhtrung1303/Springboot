package com.onlab_10.todolist.request;

public class UpdateTodoRequest {
    
}
