package com.onlab_10.todolist.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.onlab_10.todolist.model.Todo;

@Service
public class TodoService {
    //  Tạo danh sách todos để quản lý
    private List<Todo> todos;
    
    // Trong contructor , tạo ra 1 số đối tượng todos
    public TodoService() {
        Random rd = new Random();
        todos = new ArrayList<>();

        todos.add(new Todo(rd.nextInt(100), "Lam bai tap", true));

    }
    
    public List<Todo> getTodos(String status) {
        return switch (status){
            case "true" -> todos.stream().filter(Todo::isStatus).collect(Collectors.toList());

            default 
        }
    }
}
