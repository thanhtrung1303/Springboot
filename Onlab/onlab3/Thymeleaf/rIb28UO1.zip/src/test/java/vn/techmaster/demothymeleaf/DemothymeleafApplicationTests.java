package vn.techmaster.demothymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemothymeleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
